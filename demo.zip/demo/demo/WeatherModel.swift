//
//  WeatherModel.swift
//  demo
//
//  Created by Sanzhar Chagirov on 31.10.2021.
//

import Foundation

struct WeatherModel: Decodable{
    let name: String
    let main: Main
    struct Main: Decodable{
        
    }
    let weather: Weather
    struct Weather: Decodable{
        
    }
}
