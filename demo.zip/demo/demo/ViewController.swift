//
//  ViewController.swift
//  demo
//
//  Created by Sanzhar Chagirov on 28.10.2021.
//

import UIKit
import CoreLocation
import Alamofire


class ViewController: UIViewController, CLLocationManagerDelegate {

    
    @IBOutlet weak var temprature: UITextView!
    
    @IBOutlet weak var cityLabel: UILabel!
    
    @IBOutlet weak var weatherConditionView: UIImageView!
    
    public let url: String = "api.openweathermap.org/data/2.5/weather"
    
    public let API_KEY: String = "bfb0b81dfd9fe2014ba096d6ef86cc18"
    
    
//    api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={API key}
        
    
    let locationManager = CLLocationManager()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.desiredAccuracy =  kCLLocationAccuracyHundredMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        // Do any additional setup after loading the view.
    }
    
    
    func getData(url: String, params: [String: Any]){
        AF.request(url, method: .get, parameters: params).responseJSON{ [self]
            response in
            switch response.result {
            case .success(_):
                do{
                    if let responseData = response.data{
                        printContent(responseData);
                        let json = try JSONDecoder().decode(type: , from: <#T##Data#>)
                    }
                    
                } catch{
                    
                }
            case .failure(let error):
                print(error)
                self.cityLabel.text = "Location is unavaliable"
            }
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[locations.count-1]
        if location.horizontalAccuracy > 0{
            locationManager.stopUpdatingLocation()
            print("Location: \(location)")
        }
        
    }
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("failed to locate user, \(error)")
        cityLabel.text="unavaliable to locate U"
    }
    
     
    
    @IBAction func switchTapDetector(_ sender: Any) {
    }
    
    @IBAction func changeCity(_ sender: Any) {
    }
    
    }

